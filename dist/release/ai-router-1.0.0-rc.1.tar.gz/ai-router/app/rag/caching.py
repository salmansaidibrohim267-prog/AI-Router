from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from typing import Any

from app.rag.config import RAGConfig
from app.rag.models import RAGResponse


class RAGCacheEntry:
    def __init__(self, key: str, query: str, response: RAGResponse, timestamp: float, prompt_version: str = ""):
        self.key = key
        self.query = query
        self.response = response
        self.timestamp = timestamp
        self.prompt_version = prompt_version


class RAGCache:
    def __init__(self, config: RAGConfig | None = None):
        self._config = config or RAGConfig()
        self._cache: OrderedDict[str, RAGCacheEntry] = OrderedDict()
        self._max_size: int = self._config.cache_max_size
        self._ttl: int = self._config.cache_ttl
        self._hits: int = 0
        self._misses: int = 0

    def get(
        self,
        query: str,
        context_hash: str = "",
        model: str = "",
        prompt_version: str = "",
    ) -> RAGResponse | None:
        if not self._config.cache_enabled:
            self._misses += 1
            return None
        key = self._make_key(query, context_hash, model, prompt_version)
        entry = self._cache.get(key)
        if entry is None:
            self._misses += 1
            return None
        if time.monotonic() - entry.timestamp > self._ttl:
            del self._cache[key]
            self._misses += 1
            return None
        self._cache.move_to_end(key)
        self._hits += 1
        entry.response.cache_hit = True
        return entry.response

    def set(
        self,
        query: str,
        response: RAGResponse,
        context_hash: str = "",
        model: str = "",
        prompt_version: str = "",
    ) -> None:
        if not self._config.cache_enabled:
            return
        key = self._make_key(query, context_hash, model, prompt_version)
        if len(self._cache) >= self._max_size:
            self._cache.popitem(last=False)
        self._cache[key] = RAGCacheEntry(
            key=key,
            query=query,
            response=response,
            timestamp=time.monotonic(),
            prompt_version=prompt_version,
        )

    def invalidate(self, query: str = "", prompt_version: str = "") -> int:
        if query and prompt_version:
            return self._invalidate_by_query_and_version(query, prompt_version)
        if query:
            return self._invalidate_by_query(query)
        if prompt_version:
            return self._invalidate_by_version(prompt_version)
        return self._invalidate_all()

    def _invalidate_by_query(self, query: str) -> int:
        removed = 0
        keys = list(self._cache.keys())
        for k in keys:
            if query in self._cache[k].query:
                del self._cache[k]
                removed += 1
        return removed

    def _invalidate_by_version(self, version: str) -> int:
        removed = 0
        keys = list(self._cache.keys())
        for k in keys:
            if self._cache[k].prompt_version == version:
                del self._cache[k]
                removed += 1
        return removed

    def _invalidate_by_query_and_version(self, query: str, version: str) -> int:
        removed = 0
        keys = list(self._cache.keys())
        for k in keys:
            entry = self._cache[k]
            if query in entry.query and entry.prompt_version == version:
                del self._cache[k]
                removed += 1
        return removed

    def _invalidate_all(self) -> int:
        count = len(self._cache)
        self._cache.clear()
        return count

    def _make_key(self, query: str, context_hash: str, model: str, prompt_version: str) -> str:
        raw = f"{query}|{context_hash}|{model}|{prompt_version}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def stats(self) -> dict[str, Any]:
        total = self._hits + self._misses
        return {
            "size": len(self._cache),
            "max_size": self._max_size,
            "ttl": self._ttl,
            "hits": self._hits,
            "misses": self._misses,
            "hit_ratio": round(self._hits / total, 4) if total > 0 else 0.0,
            "enabled": self._config.cache_enabled,
        }
