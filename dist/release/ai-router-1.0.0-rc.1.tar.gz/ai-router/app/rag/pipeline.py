from __future__ import annotations

import asyncio
import time
from typing import Any, AsyncIterator

from app.rag.caching import RAGCache
from app.rag.config import RAGConfig
from app.rag.context_builder import ContextBuilder
from app.rag.exceptions import RAGGenerationError
from app.rag.fallback import FallbackHandler
from app.rag.logging import RAGLogger
from app.rag.models import (
    ContextAssembly,
    ConversationTurn,
    RAGMetrics,
    RAGRequest,
    RAGResponse,
)
from app.rag.prompt_builder import PromptBuilder
from app.rag.query_processor import QueryProcessor
from app.rag.retrieval_orchestrator import RetrievalOrchestrator
from app.rag.statistics import RAGMetricsTracker
from app.models import ChatRequest, Message
from app.providers.manager import provider_manager


class RAGPipeline:
    def __init__(
        self,
        config: RAGConfig | None = None,
        query_processor: QueryProcessor | None = None,
        retrieval_orchestrator: RetrievalOrchestrator | None = None,
        context_builder: ContextBuilder | None = None,
        prompt_builder: PromptBuilder | None = None,
        cache: RAGCache | None = None,
        logger: RAGLogger | None = None,
        metrics_tracker: RAGMetricsTracker | None = None,
        fallback_handler: FallbackHandler | None = None,
    ):
        self._config = config or RAGConfig()
        self._query_processor = query_processor or QueryProcessor(self._config)
        self._retrieval = retrieval_orchestrator or RetrievalOrchestrator(self._config)
        self._context_builder = context_builder or ContextBuilder(self._config)
        self._prompt_builder = prompt_builder or PromptBuilder(self._config)
        self._cache = cache or RAGCache(self._config)
        self._logger = logger or RAGLogger()
        self._metrics = metrics_tracker or RAGMetricsTracker()
        self._fallback = fallback_handler or FallbackHandler(self._config)

    async def generate(self, request: RAGRequest) -> RAGResponse:
        t_start = time.perf_counter()
        query = request.query.strip()
        if not query:
            raise RAGGenerationError("Query must not be empty")

        self._logger.log_request(request)

        cache_hit = self._check_cache(request)
        if cache_hit is not None:
            return cache_hit

        t_qa = time.perf_counter()
        query_analysis = await self._query_processor.process(query)
        t_ret_start = time.perf_counter()
        retrieval_latency = 0.0

        try:
            chunks = await self._retrieval.retrieve(
                query=query_analysis.expanded or query,
                top_k=request.retrieval_top_k,
                rerank_top_k=request.rerank_top_k,
            )
            retrieval_latency = (time.perf_counter() - t_ret_start) * 1000
        except Exception:
            retrieval_latency = (time.perf_counter() - t_ret_start) * 1000
            fallback_msg = await self._fallback.handle_retrieval_failure(query)
            response = RAGResponse(
                answer=fallback_msg,
                query_analysis=query_analysis,
                model="",
                provider="",
                total_latency_ms=(time.perf_counter() - t_start) * 1000,
                retrieval_latency_ms=retrieval_latency,
                token_usage={},
                confidence=0.0,
                fallback_used=True,
            )
            self._log_and_metrics(response, t_start, retrieval_latency, True)
            return response

        context = self._context_builder.build(
            chunks=chunks,
            token_budget=request.context_token_budget,
        )

        provider_name = request.provider_override or self._config.provider
        model = self._config.model
        provider = provider_manager.get(provider_name)

        if provider is None:
            fallback_msg = await self._fallback.handle_retrieval_failure(query)
            response = RAGResponse(
                answer=fallback_msg,
                query_analysis=query_analysis,
                context=context,
                model=model,
                provider=provider_name,
                total_latency_ms=(time.perf_counter() - t_start) * 1000,
                retrieval_latency_ms=retrieval_latency,
                token_usage={},
                confidence=0.0,
                fallback_used=True,
            )
            self._log_and_metrics(response, t_start, retrieval_latency, True)
            return response

        provider_key = f"{provider_name}/{model}"
        history = request.conversation_history or []

        messages = self._prompt_builder.build(
            query=query,
            context=context,
            history=history,
            system_prompt=request.system_prompt,
            query_analysis=query_analysis,
        )

        chat_request = ChatRequest(
            model=model,
            messages=[Message(role=m["role"], content=m["content"]) for m in messages],
            temperature=request.temperature or self._config.temperature,
            max_tokens=request.max_tokens or self._config.max_tokens,
        )

        t_llm_start = time.perf_counter()
        llm_latency = 0.0
        fallback_used = False

        try:
            chat_response = await provider.chat(chat_request)
            llm_latency = (time.perf_counter() - t_llm_start) * 1000
        except Exception as e:
            llm_latency = (time.perf_counter() - t_llm_start) * 1000
            fallback_used = True
            fallback_answer = await self._fallback.handle_llm_timeout(query)
            response = RAGResponse(
                answer=fallback_answer,
                query_analysis=query_analysis,
                context=context,
                model=model,
                provider=provider_name,
                total_latency_ms=(time.perf_counter() - t_start) * 1000,
                retrieval_latency_ms=retrieval_latency,
                llm_latency_ms=llm_latency,
                token_usage={},
                confidence=0.0,
                fallback_used=True,
            )
            self._logger.log_error(e, query)
            self._metrics.record_error()
            self._log_and_metrics(response, t_start, retrieval_latency, True)
            return response

        answer = chat_response.choices[0].message.content if chat_response.choices else ""
        usage = chat_response.usage
        token_usage = {
            "prompt_tokens": usage.prompt_tokens if usage else 0,
            "completion_tokens": usage.completion_tokens if usage else 0,
            "total_tokens": usage.total_tokens if usage else 0,
        }

        context_hash = self._compute_context_hash(context)
        self._cache.set(
            query=query,
            response=RAGResponse(
                answer=answer,
                query_analysis=query_analysis,
                context=context,
                sources=[c.to_dict() for c in chunks],
                model=model,
                provider=provider_name,
                total_latency_ms=(time.perf_counter() - t_start) * 1000,
                retrieval_latency_ms=retrieval_latency,
                llm_latency_ms=llm_latency,
                token_usage=token_usage,
                confidence=query_analysis.confidence,
                fallback_used=fallback_used,
            ),
            context_hash=context_hash,
            model=provider_key,
            prompt_version=self._config.prompt_version,
        )

        response = RAGResponse(
            answer=answer,
            query_analysis=query_analysis,
            context=context,
            sources=[c.to_dict() for c in chunks],
            model=model,
            provider=provider_name,
            total_latency_ms=(time.perf_counter() - t_start) * 1000,
            retrieval_latency_ms=retrieval_latency,
            llm_latency_ms=llm_latency,
            token_usage=token_usage,
            confidence=query_analysis.confidence,
            fallback_used=fallback_used,
        )
        self._log_and_metrics(response, t_start, retrieval_latency, fallback_used)
        return response

    async def generate_async(self, request: RAGRequest) -> RAGResponse:
        return await self.generate(request)

    async def stream(
        self,
        request: RAGRequest,
    ) -> AsyncIterator[str]:
        t_start = time.perf_counter()
        query = request.query.strip()
        if not query:
            raise RAGGenerationError("Query must not be empty")

        self._logger.log_request(request)

        query_analysis = await self._query_processor.process(query)
        try:
            chunks = await self._retrieval.retrieve(
                query=query_analysis.expanded or query,
                top_k=request.retrieval_top_k,
                rerank_top_k=request.rerank_top_k,
            )
        except Exception:
            fallback_msg = await self._fallback.handle_retrieval_failure(query)
            yield fallback_msg
            return

        context = self._context_builder.build(
            chunks=chunks,
            token_budget=request.context_token_budget,
        )

        provider_name = request.provider_override or self._config.provider
        model = self._config.model
        provider = provider_manager.get(provider_name)

        if provider is None:
            yield "Provider unavailable."
            return

        messages = self._prompt_builder.build(
            query=query,
            context=context,
            history=request.conversation_history or [],
            system_prompt=request.system_prompt,
            query_analysis=query_analysis,
        )

        chat_request = ChatRequest(
            model=model,
            messages=[Message(role=m["role"], content=m["content"]) for m in messages],
            temperature=request.temperature or self._config.temperature,
            max_tokens=request.max_tokens or self._config.max_tokens,
            stream=True,
        )

        full_text_parts: list[str] = []
        try:
            async for chunk in provider.stream_chat(chat_request):
                for choice in chunk.choices:
                    content = choice.delta.get("content", "")
                    if content:
                        full_text_parts.append(content)
                        yield content
        except Exception:
            yield "\n[Generation interrupted by error]"

        total_latency = (time.perf_counter() - t_start) * 1000
        response = RAGResponse(
            answer="".join(full_text_parts),
            query_analysis=query_analysis,
            context=context,
            sources=[c.to_dict() for c in chunks],
            model=model,
            provider=provider_name,
            total_latency_ms=total_latency,
            token_usage={},
            confidence=query_analysis.confidence,
        )
        self._logger.log_response(response, total_latency)

    async def batch_generate(
        self,
        requests: list[RAGRequest],
        max_concurrency: int = 5,
    ) -> list[RAGResponse]:
        semaphore = asyncio.Semaphore(max_concurrency)

        async def _run(req: RAGRequest) -> RAGResponse:
            async with semaphore:
                return await self.generate(req)

        tasks = [_run(req) for req in requests]
        return await asyncio.gather(*tasks, return_exceptions=False)

    def _check_cache(self, request: RAGRequest) -> RAGResponse | None:
        if not self._config.cache_enabled:
            return None
        provider_name = request.provider_override or self._config.provider
        model = self._config.model
        provider_key = f"{provider_name}/{model}"
        return self._cache.get(
            query=request.query,
            model=provider_key,
            prompt_version=self._config.prompt_version,
        )

    def _compute_context_hash(self, context: ContextAssembly) -> str:
        import hashlib
        raw = "|".join(
            f"{c.chunk_id}:{c.score}:{c.rerank_score}" for c in context.chunks
        )
        return hashlib.md5(raw.encode()).hexdigest()

    def _log_and_metrics(
        self,
        response: RAGResponse,
        t_start: float,
        retrieval_latency_ms: float,
        fallback_used: bool,
    ) -> None:
        total_latency = (time.perf_counter() - t_start) * 1000
        response.total_latency_ms = total_latency
        self._logger.log_response(response, total_latency)
        if self._config.track_metrics:
            self._metrics.record_request(
                total_latency_ms=total_latency,
                retrieval_latency_ms=retrieval_latency_ms,
                llm_latency_ms=response.llm_latency_ms,
                cache_hit=response.cache_hit,
                fallback=fallback_used,
            )

    def get_metrics(self) -> RAGMetrics:
        return self._metrics.get_metrics()
