"""Changelog generation from Conventional Commits and release history.

Parses commit messages of the form ``type(scope): subject`` and groups them
under ``Added / Changed / Deprecated / Removed / Fixed / Security`` sections.
Supports generating a complete CHANGELOG.md and per-release sections.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .exceptions import ChangelogError

_COMMIT_RE = re.compile(r"^(?P<type>[a-z]+)(?:\((?P<scope>[^)]+)\))?(?P<breaking>!)?:\s+(?P<subject>.+)$")

_SECTION_ORDER = [
    ("added", "Added"),
    ("changed", "Changed"),
    ("deprecated", "Deprecated"),
    ("removed", "Removed"),
    ("fixed", "Fixed"),
    ("security", "Security"),
]

_TYPE_TO_SECTION = {
    "feat": "added",
    "feature": "added",
    "fix": "fixed",
    "bugfix": "fixed",
    "deprecate": "deprecated",
    "remove": "removed",
    "security": "security",
    "cve": "security",
}


@dataclass
class CommitEntry:
    """A parsed conventional commit."""

    type: str
    subject: str
    scope: str = ""
    breaking: bool = False
    sha: str = ""
    author: str = ""

    @classmethod
    def parse(cls, line: str, sha: str = "", author: str = "") -> "CommitEntry | None":
        match = _COMMIT_RE.match(line.strip())
        if match is None:
            return None
        return cls(
            type=match.group("type").lower(),
            subject=match.group("subject").strip(),
            scope=match.group("scope") or "",
            breaking=bool(match.group("breaking")),
            sha=sha,
            author=author,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type,
            "subject": self.subject,
            "scope": self.scope,
            "breaking": self.breaking,
            "sha": self.sha,
            "author": self.author,
        }


@dataclass
class ReleaseEntry:
    """A single release section in the changelog."""

    version: str
    date: str = ""
    commits: list[CommitEntry] = field(default_factory=list)

    def sections(self) -> dict[str, list[CommitEntry]]:
        sections: dict[str, list[CommitEntry]] = {}
        for key, _label in _SECTION_ORDER:
            sections[key] = []
        for commit in self.commits:
            key = _TYPE_TO_SECTION.get(commit.type, "changed")
            sections[key].append(commit)
        return sections

    def markdown(self) -> str:
        lines = [f"## [{self.version}](https://github.com/anomalyco/ai-router/releases/tag/v{self.version}) - {self.date}"]
        sections = self.sections()
        breaking = [c for c in self.commits if c.breaking]
        if breaking:
            lines.append("")
            lines.append("### BREAKING CHANGES")
            for commit in breaking:
                lines.append(f"- {commit.subject} ({commit.scope or commit.type})")
        for key, label in _SECTION_ORDER:
            entries = sections[key]
            if not entries:
                continue
            lines.append("")
            lines.append(f"### {label}")
            for commit in entries:
                scope = f"**{commit.scope}:** " if commit.scope else ""
                breaking_mark = "**BREAKING:** " if commit.breaking else ""
                lines.append(f"- {scope}{breaking_mark}{commit.subject}")
        if not self.commits:
            lines.append("")
            lines.append("- Initial release.")
        return "\n".join(lines) + "\n"


class ChangelogGenerator:
    """Generates changelog documents from raw commit lines."""

    def __init__(self, project_name: str = "ai-router", header: str = "") -> None:
        self.project_name = project_name
        self.header = header or f"# Changelog\n\nAll notable changes to **{project_name}** are documented here."

    def parse_commits(self, lines: list[str]) -> list[CommitEntry]:
        entries: list[CommitEntry] = []
        for line in lines:
            entry = CommitEntry.parse(line)
            if entry is not None:
                entries.append(entry)
        return entries

    def build_entry(
        self,
        version: str,
        commits: list[CommitEntry],
        date: str | None = None,
    ) -> ReleaseEntry:
        from datetime import date as _date

        return ReleaseEntry(
            version=version,
            date=date or _date.today().isoformat(),
            commits=commits,
        )

    def generate(self, releases: list[ReleaseEntry]) -> str:
        if not releases:
            raise ChangelogError("no release entries to generate")
        lines = [self.header, ""]
        for release in releases:
            lines.append(release.markdown())
        return "\n".join(lines)

    def generate_from_commits(
        self,
        version: str,
        commit_lines: list[str],
        date: str | None = None,
    ) -> str:
        entries = self.parse_commits(commit_lines)
        release = self.build_entry(version, entries, date)
        return self.generate([release])

    @staticmethod
    def parse_changelog(text: str) -> list[ReleaseEntry]:
        """Parse an existing CHANGELOG.md back into release entries."""
        releases: list[ReleaseEntry] = []
        current: ReleaseEntry | None = None
        bullet_re = re.compile(
            r"^\s*-\s+(?:(?P<scope>\*\*[^*]+:\*\*\s+))?(?:(?P<breaking>\*\*BREAKING:\*\*\s+))?(?P<subject>.+?)\s*$"
        )
        for line in text.splitlines():
            match = re.match(r"^## \[(.+?)\]", line.strip())
            if match:
                current = ReleaseEntry(version=match.group(1))
                releases.append(current)
                continue
            if current is None:
                continue
            entry = CommitEntry.parse(line)
            if entry is not None:
                current.commits.append(entry)
                continue
            bullet = bullet_re.match(line.strip())
            if bullet:
                current.commits.append(
                    CommitEntry(
                        type="changed",
                        subject=bullet.group("subject").strip(),
                        scope=(bullet.group("scope") or "").strip(":* "),
                        breaking=bool(bullet.group("breaking")),
                    )
                )
        return releases
